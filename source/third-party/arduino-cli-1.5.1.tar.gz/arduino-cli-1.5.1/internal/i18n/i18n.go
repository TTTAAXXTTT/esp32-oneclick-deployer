// This file is part of arduino-cli.
//
// Copyright 2020 ARDUINO SA (http://www.arduino.cc/)
//
// This software is released under the GNU General Public License version 3,
// which covers the main part of arduino-cli.
// The terms of this license can be found at:
// https://www.gnu.org/licenses/gpl-3.0.en.html
//
// You can be released from the requirements of the above licenses by purchasing
// a commercial license. Buying such a license is mandatory if you want to
// modify or otherwise use the software for commercial activities involving the
// Arduino software without disclosing the source code of your own applications.
// To purchase a commercial license, send an email to license@arduino.cc.

package i18n

import "fmt"

type Locale interface {
	Get(msg string, args ...any) string
}

type nullLocale struct{}

func (n nullLocale) Parse([]byte) {}

func (n nullLocale) Get(msg string, args ...any) string {
	return fmt.Sprintf(msg, args...)
}

var locale Locale = &nullLocale{}

func SetLocale(l Locale) {
	locale = l
}

// Tr returns msg translated to the selected locale
// the msg argument must be a literal string
func Tr(msg string, args ...any) string {
	return locale.Get(msg, args...)
}
